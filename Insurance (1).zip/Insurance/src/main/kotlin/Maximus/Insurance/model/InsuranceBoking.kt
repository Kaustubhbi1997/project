package Maximus.Insurance.model

import org.springframework.data.mongodb.core.mapping.Document

@Document(collection = "Book")
data class InsuranceBoking (
   var booking_id :String?,
   var bookinguser :String

   )
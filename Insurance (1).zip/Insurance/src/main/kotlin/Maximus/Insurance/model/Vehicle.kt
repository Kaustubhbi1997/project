package Maximus.Insurance.model

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document

@Document(collection = "vehicle")
data class Vehicle (
    @Id
    var vehicleID: String?,
    var vehicleName: String?,
    var vehicleNumber: Long?,
    //var insurance:Insurance

    )
